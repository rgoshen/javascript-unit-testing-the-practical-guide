function transformToNumber(value) {
  return +value;
}

exports.transformToNumber = transformToNumber;
